package com.example.library.components.trimrangeslider

object Constants {
    const val PREVIEW_VIDEO_DURATION_MILLIS = 2000L
    const val TRIM_SLIDER_UPDATE_INTERVAL_MILLIS = 250L
}