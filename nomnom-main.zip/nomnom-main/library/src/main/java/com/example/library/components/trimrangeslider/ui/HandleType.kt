package com.example.library.components.trimrangeslider.ui

enum class HandleType {
    LEFT, RIGHT, CURSOR
}