pluginManagement {
    repositories {
        google {
            content {
                includeGroupByRegex("com\\.android.*")
                includeGroupByRegex("com\\.google.*")
                includeGroupByRegex("androidx.*")
            }
        }
        mavenCentral()
        gradlePluginPortal()
    }
}
dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
        maven("https://jitpack.io")
        maven{
            url = uri("https://maven.pkg.github.com/dexter365-afk/testlib")
            credentials {
                username = "dexter365-afk"
                password = "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"
            }
        }
    }

}

rootProject.name = "nomnom"
include(":app")
include(":library")
include(":stubs")
