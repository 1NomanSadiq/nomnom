package com.example.myapplication.ui.video_cropping

data class CroppingData(
    val cropStart: Float = 0f,
    val cropEnd: Float = 1f
)